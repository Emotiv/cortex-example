#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

  
# Import target "Qt6::Service" for configuration "RelWithDebInfo"
set_property(TARGET Qt6::Service APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Qt6::Service PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libQt6Service.so.2.0.2"
  IMPORTED_SONAME_RELWITHDEBINFO "libQt6Service.so.2"
  )

list(APPEND _IMPORT_CHECK_TARGETS Qt6::Service )
list(APPEND _IMPORT_CHECK_FILES_FOR_Qt6::Service "${_IMPORT_PREFIX}/lib/libQt6Service.so.2.0.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
