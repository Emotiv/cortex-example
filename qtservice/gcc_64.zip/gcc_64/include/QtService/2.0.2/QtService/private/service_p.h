#ifndef QTSERVICE_SERVICE_P_H
#define QTSERVICE_SERVICE_P_H

#include "service.h"
#include "servicebackend.h"
#include "terminalserver_p.h"

#include <QtCore/QPointer>
#include <QtCore/QLoggingCategory>

namespace QtService {

class ServiceControl;
class ServicePrivate
{
	Q_DISABLE_COPY(ServicePrivate)
public:
	ServicePrivate(Service *q_ptr, int &argc, char **argv, int flags);

	static QStringList listBackends();
	static QString idFromName(const QString &provider, const QString &serviceName, const QString &domain);
	static ServiceControl *createControl(const QString &provider, QString &&serviceId, QObject *parent);
	static ServiceControl *createLocalControl(const QString &provider, QObject *parent);
	static QDir runtimeDir(const QString &serviceName = QCoreApplication::applicationName());

	static QPointer<Service> instance;

	int &argc;
	char **argv;
	int flags;

	QString backendProvider;
	ServiceBackend *backend = nullptr;
	QHash<QByteArray, std::function<QVariant(QVariantList)>> callbacks;

	bool isRunning = false;
	bool wasPaused = false;
	bool terminalActive = false;
	Service::TerminalMode terminalMode = Service::TerminalMode::ReadWriteActive;
	bool terminalGlobal = false;
	bool startWithTerminal = false;

	TerminalServer *termServer = nullptr;

	void startTerminals();
	void stopTerminals();

private:
	Service *q;
};

Q_DECLARE_LOGGING_CATEGORY(logSvc)

}

#endif // QTSERVICE_SERVICE_P_H
